# IHRD-Calicut-team-1

A fully functional disaster management website with Email Alert and AI fake detection, It will predict the fairness of the disaster reporting. 
User can report a disaster and the system will sort out all nearby Shops, service, hospitals and Volunteers
